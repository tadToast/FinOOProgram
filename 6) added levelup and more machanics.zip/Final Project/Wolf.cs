﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    public class Wolf:Enemy
    {
        public string imagepath = "Wolf.jpg";


        public Wolf()
        {
            lvl = 1;
            maxattack = 15;
            minattack = 5;
            health = 15;
            name = "Big Bad Wolf";
            gold = rand.Next(110, 150);
            exp = rand.Next(100, 120);
            startDio = " A lvl " + lvl + "wimpy 'wolf' has appeared";
        }
        public Wolf(int level)
        {
            if(level == 1)
            level = rand.Next(level, level + 2);
            else
                level = rand.Next(level-1, level + 2);
            lvl = level;
            maxattack = 10 * lvl;
            minattack = 3 * lvl;
            health = 15 * lvl;
            name = "Super Mean Wolf";
            gold = rand.Next(110 * lvl, 130 * lvl);
            exp = rand.Next(100 * lvl, 120 * lvl);
            startDio = " A lvl " + lvl + " Hulking 'Wolf' has appeared";
        }

        public int Maul()
        {
            int genText = rand.Next(1, 4);
            int act = rand.Next(1, 3);
            if (act == 1)
            {
                int damage = rand.Next(minattack, maxattack);
                if (genText == 1)
                    attackText = "*snarl";
                else if (genText == 2)
                    attackText = "*bark *bark ";
                else
                    attackText = "*howl";

                return damage;
            }
            else
            {
                this.maxattack = this.maxattack * 2;
                this.minattack = this.minattack * 2;
                if (genText == 1)
                    attackText = "Goon Squad USA all the way";
                else if (genText == 2)
                    attackText = "Woof Woof *pnating";
                else
                    attackText = "Watch your back Buster";
                return 0;
            }
        }
    }
}
