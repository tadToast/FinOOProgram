﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
{
    public partial class Form2 : Form
    {
        // Just using these for my button events
        int notClicked = 0;
        int damageFromBut;
        hero a;
        ShirtlessOldMan man;
        Wolf wolf;
        JamesCordan james;
        Prince prince;
        Form1 orginal;
        int com;
        /// 
        /// //////////
        ///
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(int guy, hero character, Form1 og)
        {
            orginal = og;
            InitializeComponent();
            com = guy;
            if(guy == 1) //shirtless old man encounter
            {
                if(character.lvl == 1)
                 man = new ShirtlessOldMan();
                else
                    man = new ShirtlessOldMan(character.lvl);
                enemyPic.Image = Image.FromFile(man.imagepath);
                a = character;
                dio.Text = man.startDio;
                hell.Text = "Health:" +man.health;
                youH.Text = "Health:" + character.health;
            }
            else if(guy == 2) //wolf encounter
            {
                if (character.lvl == 1)
                    wolf = new Wolf();
                else
                    wolf = new Wolf(character.lvl);
                enemyPic.Image = Image.FromFile(wolf.imagepath);
                a = character;
                dio.Text = wolf.startDio;
                hell.Text = "Health:" + wolf.health;
                youH.Text = "Health:" + a.health;
            }
            else if ( guy == 3)//james cordan encounter
            {
                if (character.lvl == 1)
                    james = new JamesCordan();
                else
                    james = new JamesCordan(character.lvl);
                enemyPic.Image = Image.FromFile(james.imagepath);
                a = character;
                dio.Text = james.startDio;
                hell.Text = "Health:" + james.health;
                youH.Text = "Health:" + a.health;
            }
            else
            {
                if (character.lvl == 1)
                    prince = new Prince();
                else
                    prince = new Prince(character.lvl);
                enemyPic.Image = Image.FromFile(prince.imagepath);
                a = character;
                dio.Text = prince.startDio;
                hell.Text = "Health:" + prince.health;
                youH.Text = "Health:" + a.health;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

  
        int combat(hero a, ShirtlessOldMan b)//have to implement some sort of turn base
        {
            int turn = 0;
            int delt;
          
           while(a.health >= 0 || b.health >=0)
            {
                if(turn == 0)
                {
                    attackBut.Enabled = true;
                    passiveBut.Enabled = true;
                  /*  while(notClicked != 0)
                    {

                    }*/
                    notClicked = 1;
                    delt = damageFromBut;
                    b.health -= delt;
                    hell.Text = "Health:" + b.health;
                }
                else
                {
                    attackBut.Enabled = false;
                    passiveBut.Enabled = false;
                    delt = b.violence();
                    dio.Text = b.attackText;
                    a.health -= delt;
                    youH.Text = "Health:" + a.health;
                }
            }
            return 1;
        }

        private void attackBut_Click(object sender, EventArgs e)
        {
            if (com==1) //shirtless old man combat
            {
                damageFromBut = a.attack();
                man.health -= damageFromBut;
                hell.Text = "Health:" + man.health;
                ShirtlessOldManTurn();

            }
            else if(com==2) //wolf combat
            {
                damageFromBut = a.attack();
                wolf.health -= damageFromBut;
                hell.Text = "Health:" + wolf.health;
                wolfTurn();
            }
            else if(com == 3) //james cordan combat
            {
                damageFromBut = a.attack();
                james.health -= damageFromBut;
                hell.Text = "Health:" + james.health;
                jamesTurn();

            }
            else if (com == 4) //prince combat
            {
                damageFromBut = a.attack();
                prince.health -= damageFromBut;
                hell.Text = "Health:" + prince.health;
                princeTurn();
            }
            
       }
        void endGame()
        {
            orginal.Show();
            orginal.endgame();
            this.Close();
        }
        void ShirtlessOldManTurn()
        {
            if (man.health <= 0)
            {
                int money = man.die();
                dio.Text = "You murdered an old man, here is " + money + " gold and " + man.exp + "exp";
                a.gold += money;
                a.exp += man.exp;
                a.levelup();
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                int delt = man.violence();
                dio.Text = man.attackText;
                a.health -= delt;
                a.healthgate();
                youH.Text = "Health:" + a.health;
                if (a.health <= 0)
                {
                    //gameover or something
                    endGame();

                }
            }
        }
        void wolfTurn()
        {
            if (wolf.health <= 0)
            {
                int money = wolf.die();
                dio.Text = "You deafeated a great beast, here is " + money + " gold and " + wolf.exp + "exp";
                a.gold += money;
                a.exp += wolf.exp;
                a.levelup();
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                int delt = wolf.Maul();
                dio.Text = wolf.attackText;
                a.health -= delt;
                a.healthgate();
                youH.Text = "Health:" + a.health;
                if (a.health <= 0)
                {
                    //gameover or something
                    endGame();

                }
            }
        }

        void jamesTurn()
        {
            if (james.health <= 0)
            {
                int money = james.die();
                dio.Text = "You deafeated british ellen, here is " + money + " gold and " + james.exp + "exp";
                a.gold += money;
                a.exp += james.exp;
                a.levelup();
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                int delt = james.ImFamous();
                dio.Text = james.attackText;
                a.health -= delt;
                a.healthgate();
                youH.Text = "Health:" + a.health;
                if (a.health <= 0)
                {
                    //gameover or something
                    endGame();

                }
            }

        }

        void princeTurn()
        {
            if (prince.health <= 0)
            {
                int money = prince.die();
                dio.Text = "You the Prince, here is " + money + " gold and " + prince.exp + "exp";
                a.gold += money;
                a.exp += prince.exp;
                a.levelup();
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                int delt = prince.gamble();
                if (delt == 4761)
                {
                    a.levelup();
                    orginal.you = a;
                    orginal.update();
                    orginal.Show();
                    this.Close();
                }
                else
                { 
                dio.Text = prince.attackText;
                a.gold -= delt;
                youH.Text = "Health:" + a.health;
                if (a.health <= 0)
                {
                    //gameover or something
                    endGame();

                }
                }
            }
        }
     


    }
}
