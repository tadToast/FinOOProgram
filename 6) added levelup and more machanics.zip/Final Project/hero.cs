﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    public class hero
    {
       public   Random rand = new Random();
     public    int health;
      static   string name = "Ted Cruz";
       public  int attackmax;
       public  int attackMin;
       public  int speed;
       public  int gold;
       public int lvl;
        public int exp;
        public int maxHealth;

        public void levelup()
        {
           
            int needed = lvl * 50;
            while (exp >= needed)
            {
                if (needed <= exp)
                {
                    this.lvl++;
                   this.exp = exp - needed; ;
                    needed = lvl * 50;
                   this.health += 5;
                    this.maxHealth += 20;
                   this.attackmax += 10;
                   this.attackMin += 3;
                   this.speed = speed * lvl;
                }
                else
                {
                    return;
                }
            }
            return;
        }
        public hero()
        {
            lvl = 1;
            health = 50 * lvl;
            maxHealth = 50 * lvl;
            attackmax = 10 * lvl;
            attackMin = 3* (lvl/2);
            speed = 100 * lvl;
            gold = 0;
        }
        public hero(hero youA)
        {
            this.lvl = youA.lvl;
            this.health = youA.health;
            this.attackmax = youA.attackmax;
            this.attackMin = youA.attackMin;
            this.speed = 100 * youA.speed;
            this.gold = youA.gold;
           this.maxHealth =youA.maxHealth;
          this.exp = youA.exp;
        }

        public int attack ()
        {
            int val;
            val = rand.Next(attackMin, attackmax+1);
            return val;

        }
        public void healthgate()
        {
            if(maxHealth < health)
            {
                this.health = maxHealth;
                return;
            }
            else
            {
                return;
            }
        }
    }
}
