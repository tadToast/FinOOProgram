﻿namespace Final_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Map = new System.Windows.Forms.PictureBox();
            this.Start = new System.Windows.Forms.PictureBox();
            this.left1 = new System.Windows.Forms.PictureBox();
            this.left2 = new System.Windows.Forms.PictureBox();
            this.left3 = new System.Windows.Forms.PictureBox();
            this.left4 = new System.Windows.Forms.PictureBox();
            this.right1 = new System.Windows.Forms.PictureBox();
            this.right2 = new System.Windows.Forms.PictureBox();
            this.right3 = new System.Windows.Forms.PictureBox();
            this.right4 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Map)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Start)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.left1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.left2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.left3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.left4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.right1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.right2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.right3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.right4)).BeginInit();
            this.SuspendLayout();
            // 
            // Map
            // 
            this.Map.Image = ((System.Drawing.Image)(resources.GetObject("Map.Image")));
            this.Map.Location = new System.Drawing.Point(-6, 1);
            this.Map.Name = "Map";
            this.Map.Size = new System.Drawing.Size(808, 451);
            this.Map.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Map.TabIndex = 0;
            this.Map.TabStop = false;
            // 
            // Start
            // 
            this.Start.Image = ((System.Drawing.Image)(resources.GetObject("Start.Image")));
            this.Start.Location = new System.Drawing.Point(355, 360);
            this.Start.Name = "Start";
            this.Start.Size = new System.Drawing.Size(56, 53);
            this.Start.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Start.TabIndex = 1;
            this.Start.TabStop = false;
            // 
            // left1
            // 
            this.left1.Image = ((System.Drawing.Image)(resources.GetObject("left1.Image")));
            this.left1.Location = new System.Drawing.Point(251, 313);
            this.left1.Name = "left1";
            this.left1.Size = new System.Drawing.Size(54, 30);
            this.left1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.left1.TabIndex = 2;
            this.left1.TabStop = false;
            // 
            // left2
            // 
            this.left2.Image = ((System.Drawing.Image)(resources.GetObject("left2.Image")));
            this.left2.Location = new System.Drawing.Point(242, 227);
            this.left2.Name = "left2";
            this.left2.Size = new System.Drawing.Size(65, 38);
            this.left2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.left2.TabIndex = 3;
            this.left2.TabStop = false;
            // 
            // left3
            // 
            this.left3.Image = ((System.Drawing.Image)(resources.GetObject("left3.Image")));
            this.left3.Location = new System.Drawing.Point(245, 159);
            this.left3.Name = "left3";
            this.left3.Size = new System.Drawing.Size(60, 41);
            this.left3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.left3.TabIndex = 4;
            this.left3.TabStop = false;
            this.left3.Click += new System.EventHandler(this.left3_Click);
            // 
            // left4
            // 
            this.left4.Image = ((System.Drawing.Image)(resources.GetObject("left4.Image")));
            this.left4.Location = new System.Drawing.Point(247, 95);
            this.left4.Name = "left4";
            this.left4.Size = new System.Drawing.Size(58, 37);
            this.left4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.left4.TabIndex = 5;
            this.left4.TabStop = false;
            // 
            // right1
            // 
            this.right1.Image = ((System.Drawing.Image)(resources.GetObject("right1.Image")));
            this.right1.Location = new System.Drawing.Point(464, 312);
            this.right1.Name = "right1";
            this.right1.Size = new System.Drawing.Size(49, 30);
            this.right1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.right1.TabIndex = 6;
            this.right1.TabStop = false;
            // 
            // right2
            // 
            this.right2.Image = ((System.Drawing.Image)(resources.GetObject("right2.Image")));
            this.right2.Location = new System.Drawing.Point(454, 230);
            this.right2.Name = "right2";
            this.right2.Size = new System.Drawing.Size(59, 35);
            this.right2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.right2.TabIndex = 7;
            this.right2.TabStop = false;
            // 
            // right3
            // 
            this.right3.Image = ((System.Drawing.Image)(resources.GetObject("right3.Image")));
            this.right3.Location = new System.Drawing.Point(458, 168);
            this.right3.Name = "right3";
            this.right3.Size = new System.Drawing.Size(54, 40);
            this.right3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.right3.TabIndex = 8;
            this.right3.TabStop = false;
            // 
            // right4
            // 
            this.right4.Image = ((System.Drawing.Image)(resources.GetObject("right4.Image")));
            this.right4.Location = new System.Drawing.Point(455, 98);
            this.right4.Name = "right4";
            this.right4.Size = new System.Drawing.Size(56, 33);
            this.right4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.right4.TabIndex = 9;
            this.right4.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.right4);
            this.Controls.Add(this.right3);
            this.Controls.Add(this.right2);
            this.Controls.Add(this.right1);
            this.Controls.Add(this.left4);
            this.Controls.Add(this.left3);
            this.Controls.Add(this.left2);
            this.Controls.Add(this.left1);
            this.Controls.Add(this.Start);
            this.Controls.Add(this.Map);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Map)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Start)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.left1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.left2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.left3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.left4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.right1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.right2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.right3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.right4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Map;
        private System.Windows.Forms.PictureBox Start;
        private System.Windows.Forms.PictureBox left1;
        private System.Windows.Forms.PictureBox left2;
        private System.Windows.Forms.PictureBox left3;
        private System.Windows.Forms.PictureBox left4;
        private System.Windows.Forms.PictureBox right1;
        private System.Windows.Forms.PictureBox right2;
        private System.Windows.Forms.PictureBox right3;
        private System.Windows.Forms.PictureBox right4;
    }
}

