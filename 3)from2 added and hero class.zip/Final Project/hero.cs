﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    internal class hero
    {
        Random rand = new Random();
        int health;
        string name = "Ted Cruz";
        int attackmax;
        int attackMin;
        int speed;
        int gold;

        hero()
        {
            health = 100;
            attackmax = 10;
            attackMin = 3;
            speed = 100;
            gold = 0;
        }

        int attack ()
        {
            int val;
            val = rand.Next(attackMin, attackmax);
            return val;

        }
    }
}
