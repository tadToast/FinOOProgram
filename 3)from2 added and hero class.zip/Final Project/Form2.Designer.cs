﻿namespace Final_Project
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.heroPic = new System.Windows.Forms.PictureBox();
            this.enemyPic = new System.Windows.Forms.PictureBox();
            this.attackBut = new System.Windows.Forms.Button();
            this.passiveBut = new System.Windows.Forms.Button();
            this.runBut = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.heroPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPic)).BeginInit();
            this.SuspendLayout();
            // 
            // heroPic
            // 
            this.heroPic.Image = ((System.Drawing.Image)(resources.GetObject("heroPic.Image")));
            this.heroPic.Location = new System.Drawing.Point(32, 107);
            this.heroPic.Name = "heroPic";
            this.heroPic.Size = new System.Drawing.Size(206, 206);
            this.heroPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heroPic.TabIndex = 0;
            this.heroPic.TabStop = false;
            // 
            // enemyPic
            // 
            this.enemyPic.Location = new System.Drawing.Point(570, 24);
            this.enemyPic.Name = "enemyPic";
            this.enemyPic.Size = new System.Drawing.Size(192, 228);
            this.enemyPic.TabIndex = 1;
            this.enemyPic.TabStop = false;
            // 
            // attackBut
            // 
            this.attackBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.attackBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("attackBut.BackgroundImage")));
            this.attackBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.attackBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.attackBut.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.attackBut.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.attackBut.Location = new System.Drawing.Point(0, 330);
            this.attackBut.Name = "attackBut";
            this.attackBut.Size = new System.Drawing.Size(238, 120);
            this.attackBut.TabIndex = 2;
            this.attackBut.Text = "Attack";
            this.attackBut.UseVisualStyleBackColor = false;
            // 
            // passiveBut
            // 
            this.passiveBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.passiveBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("passiveBut.BackgroundImage")));
            this.passiveBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.passiveBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.passiveBut.ForeColor = System.Drawing.Color.Blue;
            this.passiveBut.Location = new System.Drawing.Point(279, 330);
            this.passiveBut.Name = "passiveBut";
            this.passiveBut.Size = new System.Drawing.Size(238, 120);
            this.passiveBut.TabIndex = 3;
            this.passiveBut.Text = "Love 😍";
            this.passiveBut.UseVisualStyleBackColor = false;
            // 
            // runBut
            // 
            this.runBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("runBut.BackgroundImage")));
            this.runBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.runBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.runBut.Location = new System.Drawing.Point(550, 330);
            this.runBut.Name = "runBut";
            this.runBut.Size = new System.Drawing.Size(238, 120);
            this.runBut.TabIndex = 4;
            this.runBut.Text = "Run🏃‍♀️🏃‍♀️";
            this.runBut.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.runBut);
            this.Controls.Add(this.passiveBut);
            this.Controls.Add(this.attackBut);
            this.Controls.Add(this.enemyPic);
            this.Controls.Add(this.heroPic);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.heroPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPic)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox heroPic;
        private System.Windows.Forms.PictureBox enemyPic;
        private System.Windows.Forms.Button attackBut;
        private System.Windows.Forms.Button passiveBut;
        private System.Windows.Forms.Button runBut;
    }
}