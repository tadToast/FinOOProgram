﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    public class Boss : Enemy
    {
        public string imagepath = "might use this for an enemy.jpg";
       public  Boss()
        {
            health = 200;
            minattack = 10;
            maxattack = 30;
            lvl = 311;
            gold = 4761;
             speed = 10000000;
            startDio = "I am Former US vice president Biden";
            name = "Biden";
        }

        public hero RaiseGasPrices(hero a)
        {
            attackText = "I RAISED GAS PRICES AGAIN!!!";
            a.gold -= 50;
            if(a.gold <= 0)
            {
                int dam = a.gold * (-1);
                a.health -= dam;
                attackText = "I HATE THE POOR!";

            }
            return a; 
        }

        public hero forget(hero a)
        {
            attackText = "I- Uhmm.. Anyway";
            a.health += 1;
            a.gold -= 5;
            a.healthgate();
            return a;
        }
        public hero fall(hero a)
        {
            attackText = "Mr. President has just fallen";
            this.health -= 30;
            a.gold -= 10;
            return a;
        }

        public hero droneStrick(hero a)
        {
            attackText = "We are bringing the troops back home";
            a.gold -= 5;
            int dam = rand.Next(minattack, maxattack);
            a.health -= dam;
            return a;
        }

        public hero gridy(hero a)
        {
            attackText = "I AM HITTING THE GRIWDY";
            a.gold -= 5;
            int dam = rand.Next((-5), 60);
            a.health -= dam;
            return a;

        }

        public hero saySomethign(hero a)
        {
            attackText = "America can be summed up in one word...";
            a.gold -= 20;
            a.health -= 10;
            return a;
        }

        public hero attack(hero a)
        {
            int decide = rand.Next(1, 7);
                if(decide == 1)
                  a  =this.RaiseGasPrices(a);
      
                else if(decide == 2)
                  a = this.forget(a);
            else if(decide == 3)
                   a = this.fall(a);
            else if(decide == 4)
                     a = this.droneStrick(a);
            else if(decide == 5)
                     a = this.gridy(a);
            else if(decide == 6)
                   a = this.saySomethign(a);

            return a;
        }




    }
}
