﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
{
    public partial class Shop : Form
    {
        int stalClick = 0;
        hero a;
        Form1 orginal;
        Boss sendOff = null;

        void update()
        {
            Gold.Text = "Gold: " + a.gold;
            Health.Text = "Health: " + a.health;
            lvlLabel.Text = "Level: " + a.lvl;
            stalinDio.Visible = false;
        }
        public Shop()
        {
            InitializeComponent();
        }
        public Shop(hero tmp, Form1 OG)
        {
            InitializeComponent();
            orginal = OG;
            a = tmp;
            update();
        }
        public Shop(hero tmp, Boss boss, Form1 OG)
        {
            InitializeComponent();
            sendOff = boss;
            orginal = OG;
            a = tmp;
            update();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (stalClick == 0)
            { 
            stal.Image = Image.FromFile("stalin blush keeper.jpg");
            stalinDio.Text = "Pwease stwop twuchwng me";
            stalinDio.Visible = true;
            stalClick++;
            }
            else stalinDio.Visible = false;

        }

        private void Leave_Click(object sender, EventArgs e)
        {
            if (sendOff == null)
            {
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                orginal.you = a;
              var m = new Combat(sendOff, a, orginal);
                m.Show();
                this.Close();
            }
        }

        private void halfHeal_Click(object sender, EventArgs e)
        {
            if(a.gold >=100)
            {
                a.gold -= 100;
                a.halfheal++;
                update();
               

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

        private void Smoke_Click(object sender, EventArgs e)
        {
            if (a.gold >= 30)
            {
                a.gold -= 30;
                a.smoke++;
                update();

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

        private void slots_Click(object sender, EventArgs e)
        {
            if (a.gold >= 75)
            {
                a.gold -= 75;
                a.slots++;
                update();

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

        private void speed_Click(object sender, EventArgs e)
        {
            if (a.gold >= 10)
            {
                a.gold -= 10;
                a.sped++;
                update();

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

        private void beserk_Click(object sender, EventArgs e)
        {
            if (a.gold >= 115)
            {
                a.gold -= 115;
                a.ber++;
                update();

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

        private void Heal_Click(object sender, EventArgs e)
        {
            if (a.gold >= 175)
            {
                a.gold -= 175;
                a.fullHeal++;
                update();

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

        private void steroids_Click(object sender, EventArgs e)
        {
            if (a.gold >= 100)
            {
                a.gold -= 100;
                a.attackMin += 15;
                a.attackmax += 15;
                a.ster++;
                update();

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

        private void stemcells_Click(object sender, EventArgs e)
        {
            if (a.gold >= 150)
            {
                a.gold -= 150;
                a.exp += a.lvlNeeded;
                a.levelup();
                a.stem++;
                update();

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

        private void meth_Click(object sender, EventArgs e)
        {
            if (a.gold >= 50)
            {
                a.gold -= 50;
                a.health -= 30;
                if(a.health <= 0)
                {
                    orginal.endgame();
                    orginal.Show();
                    this.Close();
                }
                a.attackmax += 40;
                a.meth++;
                update();

            }
            else
            {
                stalinDio.Text = "You do not have enough money 😡";
                stalinDio.Visible = true;
            }
        }

       
    }
}
