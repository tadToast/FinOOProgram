﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    abstract public  class Enemy
    {
       public static  Random rand = new Random();
       public  int maxattack;
       public  int minattack;
        public int health;
        public int lvl;
       public  string name;
        public int gold;
        public int exp;
        public int speed;
        public string attackText;
        public string startDio;
        

        public  int die()
        {
            if(health <= 0)
            {
                return gold;
            }
            return 0;
        }


    }
}
