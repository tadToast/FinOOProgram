﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    public class JamesCordan : Enemy
    {
        public string imagepath = "James Cordan.jpg";


        public JamesCordan()
        {
            lvl = 1;
            maxattack = 3;
            minattack = 0;
            health = 40;
            name = "James Cordan";
            gold = rand.Next(75, 100);
            exp = rand.Next(90, 95);
            startDio = " A lvl " + lvl + " weak lazy comidean has appeared";
        }
        public JamesCordan(int level)
        {
            if (level == 1)
                level = rand.Next(level, level + 2);
            else
                level = rand.Next(level - 1, level + 2);
            lvl = level;
            maxattack = 5 * lvl;
            minattack = 1 * lvl;
            health = 40 * lvl;
            name = "Angry James Cordan";
            gold = rand.Next(60 * lvl, 90 * lvl);
            exp = rand.Next(95 * lvl, 110 * lvl);
            startDio = " A lvl " + lvl + " Ellen Clone  has appeared";
        }

        public int ImFamous()
        {
            int genText = rand.Next(1, 4);
            int act = rand.Next(1, 4);
            if (act == 1)
            {
                int damage = rand.Next(minattack, maxattack);
                if (genText == 1)
                    attackText = "You are fatphobic and racist";
                else if (genText == 2)
                    attackText = "You are a meanie pants";
                else
                    attackText = "Erm, you suck more than a vacuum";

                return damage;
            }
            else if(act == 2)
            {
                int heal;
                heal = rand.Next(1, 5);
                heal = heal * (-1);
                if (genText == 1)
                    attackText = "You should join me on carpool Karaoke";
                else if (genText == 2)
                    attackText = "I have made a lasp in my jugment";
                else
                    attackText = "Look under your chair, free health";
                return heal;
            }
            else
            {
                this.health = this.health + 8;

                if (genText == 1)
                    attackText = "Have you seen my carpool Karaoke";
                else if (genText == 2)
                    attackText = "I collabed with Justin Beber";
                else
                    attackText = "I am a famous Actor, unlike you";
                return 0;
            }
        }
    }
}
