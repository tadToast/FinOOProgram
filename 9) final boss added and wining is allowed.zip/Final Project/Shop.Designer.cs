﻿namespace Final_Project
{
    partial class Shop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shop));
            this.stal = new System.Windows.Forms.PictureBox();
            this.stalinDio = new System.Windows.Forms.Label();
            this.Gold = new System.Windows.Forms.Label();
            this.Health = new System.Windows.Forms.Label();
            this.Leave = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.halfHeal = new System.Windows.Forms.Button();
            this.Smoke = new System.Windows.Forms.Button();
            this.slots = new System.Windows.Forms.Button();
            this.speed = new System.Windows.Forms.Button();
            this.beserk = new System.Windows.Forms.Button();
            this.Heal = new System.Windows.Forms.Button();
            this.steroids = new System.Windows.Forms.Button();
            this.meth = new System.Windows.Forms.Button();
            this.stemcells = new System.Windows.Forms.Button();
            this.lvlLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.stal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // stal
            // 
            this.stal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stal.BackgroundImage")));
            this.stal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.stal.Location = new System.Drawing.Point(632, 191);
            this.stal.Name = "stal";
            this.stal.Size = new System.Drawing.Size(201, 271);
            this.stal.TabIndex = 0;
            this.stal.TabStop = false;
            this.stal.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // stalinDio
            // 
            this.stalinDio.AutoSize = true;
            this.stalinDio.Font = new System.Drawing.Font("MV Boli", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stalinDio.Location = new System.Drawing.Point(460, 475);
            this.stalinDio.Name = "stalinDio";
            this.stalinDio.Size = new System.Drawing.Size(192, 25);
            this.stalinDio.TabIndex = 1;
            this.stalinDio.Text = "I am the shop Dio";
            this.stalinDio.Visible = false;
            // 
            // Gold
            // 
            this.Gold.AutoSize = true;
            this.Gold.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Gold.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Gold.Location = new System.Drawing.Point(3, 3);
            this.Gold.Name = "Gold";
            this.Gold.Size = new System.Drawing.Size(54, 18);
            this.Gold.TabIndex = 2;
            this.Gold.Text = "Gold: ";
            // 
            // Health
            // 
            this.Health.AutoSize = true;
            this.Health.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Health.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Health.Location = new System.Drawing.Point(3, 25);
            this.Health.Name = "Health";
            this.Health.Size = new System.Drawing.Size(66, 18);
            this.Health.TabIndex = 3;
            this.Health.Text = "Health: ";
            // 
            // Leave
            // 
            this.Leave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Leave.BackgroundImage")));
            this.Leave.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Leave.ForeColor = System.Drawing.Color.White;
            this.Leave.Image = ((System.Drawing.Image)(resources.GetObject("Leave.Image")));
            this.Leave.Location = new System.Drawing.Point(723, 12);
            this.Leave.Name = "Leave";
            this.Leave.Size = new System.Drawing.Size(102, 40);
            this.Leave.TabIndex = 4;
            this.Leave.Text = "Leave";
            this.Leave.UseVisualStyleBackColor = true;
            this.Leave.Click += new System.EventHandler(this.Leave_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(11, 53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(94, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(154, 53);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(94, 117);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(282, 53);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(94, 117);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(414, 53);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(94, 117);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(12, 292);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(94, 117);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 9;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(154, 292);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(94, 117);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 10;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(282, 292);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(94, 117);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 11;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(414, 292);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(94, 117);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 12;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(558, 53);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(94, 117);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 13;
            this.pictureBox9.TabStop = false;
            // 
            // halfHeal
            // 
            this.halfHeal.Location = new System.Drawing.Point(13, 177);
            this.halfHeal.Name = "halfHeal";
            this.halfHeal.Size = new System.Drawing.Size(92, 52);
            this.halfHeal.TabIndex = 14;
            this.halfHeal.Text = "100g Half heal Consumable";
            this.halfHeal.UseVisualStyleBackColor = true;
            this.halfHeal.Click += new System.EventHandler(this.halfHeal_Click);
            // 
            // Smoke
            // 
            this.Smoke.Location = new System.Drawing.Point(154, 177);
            this.Smoke.Name = "Smoke";
            this.Smoke.Size = new System.Drawing.Size(92, 52);
            this.Smoke.TabIndex = 15;
            this.Smoke.Text = "30g Smokebomb Consumable";
            this.Smoke.UseVisualStyleBackColor = true;
            this.Smoke.Click += new System.EventHandler(this.Smoke_Click);
            // 
            // slots
            // 
            this.slots.Location = new System.Drawing.Point(284, 177);
            this.slots.Name = "slots";
            this.slots.Size = new System.Drawing.Size(92, 52);
            this.slots.TabIndex = 16;
            this.slots.Text = "75g slot machine consumable";
            this.slots.UseVisualStyleBackColor = true;
            this.slots.Click += new System.EventHandler(this.slots_Click);
            // 
            // speed
            // 
            this.speed.Location = new System.Drawing.Point(414, 177);
            this.speed.Name = "speed";
            this.speed.Size = new System.Drawing.Size(92, 52);
            this.speed.TabIndex = 17;
            this.speed.Text = "10g Speed Consumable";
            this.speed.UseVisualStyleBackColor = true;
            this.speed.Click += new System.EventHandler(this.speed_Click);
            // 
            // beserk
            // 
            this.beserk.Location = new System.Drawing.Point(558, 177);
            this.beserk.Name = "beserk";
            this.beserk.Size = new System.Drawing.Size(92, 52);
            this.beserk.TabIndex = 18;
            this.beserk.Text = "115g Beserk Consumable";
            this.beserk.UseVisualStyleBackColor = true;
            this.beserk.Click += new System.EventHandler(this.beserk_Click);
            // 
            // Heal
            // 
            this.Heal.Location = new System.Drawing.Point(14, 415);
            this.Heal.Name = "Heal";
            this.Heal.Size = new System.Drawing.Size(99, 52);
            this.Heal.TabIndex = 19;
            this.Heal.Text = "175g SweetBabyRays  Consumable";
            this.Heal.UseVisualStyleBackColor = true;
            this.Heal.Click += new System.EventHandler(this.Heal_Click);
            // 
            // steroids
            // 
            this.steroids.Location = new System.Drawing.Point(156, 415);
            this.steroids.Name = "steroids";
            this.steroids.Size = new System.Drawing.Size(92, 52);
            this.steroids.TabIndex = 20;
            this.steroids.Text = "100g Steroids ";
            this.steroids.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.steroids.UseVisualStyleBackColor = true;
            this.steroids.Click += new System.EventHandler(this.steroids_Click);
            // 
            // meth
            // 
            this.meth.Location = new System.Drawing.Point(282, 415);
            this.meth.Name = "meth";
            this.meth.Size = new System.Drawing.Size(92, 52);
            this.meth.TabIndex = 21;
            this.meth.Text = "50g meth (dangerous)";
            this.meth.UseVisualStyleBackColor = true;
            this.meth.Click += new System.EventHandler(this.meth_Click);
            // 
            // stemcells
            // 
            this.stemcells.Location = new System.Drawing.Point(416, 415);
            this.stemcells.Name = "stemcells";
            this.stemcells.Size = new System.Drawing.Size(92, 52);
            this.stemcells.TabIndex = 22;
            this.stemcells.Text = "150g Stem Cells";
            this.stemcells.UseVisualStyleBackColor = true;
            this.stemcells.Click += new System.EventHandler(this.stemcells_Click);
            // 
            // lvlLabel
            // 
            this.lvlLabel.AutoSize = true;
            this.lvlLabel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.lvlLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlLabel.Location = new System.Drawing.Point(104, 3);
            this.lvlLabel.Name = "lvlLabel";
            this.lvlLabel.Size = new System.Drawing.Size(57, 18);
            this.lvlLabel.TabIndex = 23;
            this.lvlLabel.Text = "Level: ";
            // 
            // Shop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(845, 509);
            this.Controls.Add(this.lvlLabel);
            this.Controls.Add(this.stemcells);
            this.Controls.Add(this.meth);
            this.Controls.Add(this.steroids);
            this.Controls.Add(this.Heal);
            this.Controls.Add(this.beserk);
            this.Controls.Add(this.speed);
            this.Controls.Add(this.slots);
            this.Controls.Add(this.Smoke);
            this.Controls.Add(this.halfHeal);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Leave);
            this.Controls.Add(this.Health);
            this.Controls.Add(this.Gold);
            this.Controls.Add(this.stalinDio);
            this.Controls.Add(this.stal);
            this.Name = "Shop";
            this.Text = "Shop";
            ((System.ComponentModel.ISupportInitialize)(this.stal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox stal;
        private System.Windows.Forms.Label stalinDio;
        private System.Windows.Forms.Label Gold;
        private System.Windows.Forms.Label Health;
        private System.Windows.Forms.Button Leave;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Button halfHeal;
        private System.Windows.Forms.Button Smoke;
        private System.Windows.Forms.Button slots;
        private System.Windows.Forms.Button speed;
        private System.Windows.Forms.Button beserk;
        private System.Windows.Forms.Button Heal;
        private System.Windows.Forms.Button steroids;
        private System.Windows.Forms.Button meth;
        private System.Windows.Forms.Button stemcells;
        private System.Windows.Forms.Label lvlLabel;
    }
}