﻿namespace Final_Project
{
    partial class Combat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Combat));
            this.heroPic = new System.Windows.Forms.PictureBox();
            this.enemyPic = new System.Windows.Forms.PictureBox();
            this.attackBut = new System.Windows.Forms.Button();
            this.passiveBut = new System.Windows.Forms.Button();
            this.runBut = new System.Windows.Forms.Button();
            this.dio = new System.Windows.Forms.Label();
            this.hell = new System.Windows.Forms.Label();
            this.youH = new System.Windows.Forms.Label();
            this.goldL = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.halfHeal = new System.Windows.Forms.Button();
            this.slots = new System.Windows.Forms.Button();
            this.smoke = new System.Windows.Forms.Button();
            this.beserk = new System.Windows.Forms.Button();
            this.sped = new System.Windows.Forms.Button();
            this.fullHeal = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.heroPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPic)).BeginInit();
            this.SuspendLayout();
            // 
            // heroPic
            // 
            this.heroPic.Image = ((System.Drawing.Image)(resources.GetObject("heroPic.Image")));
            this.heroPic.Location = new System.Drawing.Point(32, 107);
            this.heroPic.Name = "heroPic";
            this.heroPic.Size = new System.Drawing.Size(206, 206);
            this.heroPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heroPic.TabIndex = 0;
            this.heroPic.TabStop = false;
            // 
            // enemyPic
            // 
            this.enemyPic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.enemyPic.Location = new System.Drawing.Point(570, 24);
            this.enemyPic.Name = "enemyPic";
            this.enemyPic.Size = new System.Drawing.Size(192, 228);
            this.enemyPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPic.TabIndex = 1;
            this.enemyPic.TabStop = false;
            // 
            // attackBut
            // 
            this.attackBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.attackBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("attackBut.BackgroundImage")));
            this.attackBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.attackBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.attackBut.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.attackBut.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.attackBut.Location = new System.Drawing.Point(0, 330);
            this.attackBut.Name = "attackBut";
            this.attackBut.Size = new System.Drawing.Size(238, 120);
            this.attackBut.TabIndex = 2;
            this.attackBut.Text = "Attack";
            this.attackBut.UseVisualStyleBackColor = false;
            this.attackBut.Click += new System.EventHandler(this.attackBut_Click);
            // 
            // passiveBut
            // 
            this.passiveBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.passiveBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("passiveBut.BackgroundImage")));
            this.passiveBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.passiveBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.passiveBut.ForeColor = System.Drawing.Color.Blue;
            this.passiveBut.Location = new System.Drawing.Point(279, 330);
            this.passiveBut.Name = "passiveBut";
            this.passiveBut.Size = new System.Drawing.Size(238, 120);
            this.passiveBut.TabIndex = 3;
            this.passiveBut.Text = "Love 😍";
            this.passiveBut.UseVisualStyleBackColor = false;
            this.passiveBut.Click += new System.EventHandler(this.passiveBut_Click);
            // 
            // runBut
            // 
            this.runBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("runBut.BackgroundImage")));
            this.runBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.runBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.runBut.Location = new System.Drawing.Point(550, 330);
            this.runBut.Name = "runBut";
            this.runBut.Size = new System.Drawing.Size(238, 120);
            this.runBut.TabIndex = 4;
            this.runBut.Text = "Run🏃‍♀️🏃‍♀️";
            this.runBut.UseVisualStyleBackColor = true;
            this.runBut.Click += new System.EventHandler(this.runBut_Click);
            // 
            // dio
            // 
            this.dio.AutoSize = true;
            this.dio.BackColor = System.Drawing.Color.Yellow;
            this.dio.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dio.ForeColor = System.Drawing.Color.Black;
            this.dio.Location = new System.Drawing.Point(311, 288);
            this.dio.Name = "dio";
            this.dio.Size = new System.Drawing.Size(0, 24);
            this.dio.TabIndex = 5;
            this.dio.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.dio.Visible = false;
            // 
            // hell
            // 
            this.hell.AutoSize = true;
            this.hell.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.hell.Location = new System.Drawing.Point(565, 227);
            this.hell.Name = "hell";
            this.hell.Size = new System.Drawing.Size(86, 25);
            this.hell.TabIndex = 6;
            this.hell.Text = "Health: ";
            // 
            // youH
            // 
            this.youH.AutoSize = true;
            this.youH.BackColor = System.Drawing.Color.Yellow;
            this.youH.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.youH.Location = new System.Drawing.Point(27, 79);
            this.youH.Name = "youH";
            this.youH.Size = new System.Drawing.Size(86, 25);
            this.youH.TabIndex = 7;
            this.youH.Text = "Health: ";
            // 
            // goldL
            // 
            this.goldL.AutoSize = true;
            this.goldL.BackColor = System.Drawing.Color.Yellow;
            this.goldL.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.goldL.Location = new System.Drawing.Point(27, 54);
            this.goldL.Name = "goldL";
            this.goldL.Size = new System.Drawing.Size(63, 25);
            this.goldL.TabIndex = 8;
            this.goldL.Text = "Gold:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Yellow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.label2.Location = new System.Drawing.Point(27, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 25);
            this.label2.TabIndex = 9;
            // 
            // halfHeal
            // 
            this.halfHeal.BackColor = System.Drawing.Color.Yellow;
            this.halfHeal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("halfHeal.BackgroundImage")));
            this.halfHeal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.halfHeal.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.halfHeal.ForeColor = System.Drawing.Color.Black;
            this.halfHeal.Location = new System.Drawing.Point(279, 107);
            this.halfHeal.Name = "halfHeal";
            this.halfHeal.Size = new System.Drawing.Size(105, 65);
            this.halfHeal.TabIndex = 10;
            this.halfHeal.Text = "half full potion";
            this.halfHeal.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.halfHeal.UseVisualStyleBackColor = false;
            this.halfHeal.Visible = false;
            this.halfHeal.Click += new System.EventHandler(this.halfHeal_Click);
            // 
            // slots
            // 
            this.slots.BackColor = System.Drawing.Color.Yellow;
            this.slots.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("slots.BackgroundImage")));
            this.slots.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.slots.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slots.ForeColor = System.Drawing.Color.Black;
            this.slots.Location = new System.Drawing.Point(411, 107);
            this.slots.Name = "slots";
            this.slots.Size = new System.Drawing.Size(105, 65);
            this.slots.TabIndex = 11;
            this.slots.Text = "slots";
            this.slots.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.slots.UseVisualStyleBackColor = false;
            this.slots.Visible = false;
            this.slots.Click += new System.EventHandler(this.slots_Click);
            // 
            // smoke
            // 
            this.smoke.BackColor = System.Drawing.Color.Yellow;
            this.smoke.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("smoke.BackgroundImage")));
            this.smoke.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.smoke.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.smoke.ForeColor = System.Drawing.Color.Black;
            this.smoke.Location = new System.Drawing.Point(279, 178);
            this.smoke.Name = "smoke";
            this.smoke.Size = new System.Drawing.Size(105, 65);
            this.smoke.TabIndex = 12;
            this.smoke.Text = "Smoke Bomb";
            this.smoke.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.smoke.UseVisualStyleBackColor = false;
            this.smoke.Visible = false;
            this.smoke.Click += new System.EventHandler(this.smoke_Click);
            // 
            // beserk
            // 
            this.beserk.BackColor = System.Drawing.Color.Yellow;
            this.beserk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("beserk.BackgroundImage")));
            this.beserk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.beserk.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.beserk.ForeColor = System.Drawing.Color.Black;
            this.beserk.Location = new System.Drawing.Point(411, 178);
            this.beserk.Name = "beserk";
            this.beserk.Size = new System.Drawing.Size(105, 65);
            this.beserk.TabIndex = 13;
            this.beserk.Text = "RedPotion";
            this.beserk.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.beserk.UseVisualStyleBackColor = false;
            this.beserk.Visible = false;
            this.beserk.Click += new System.EventHandler(this.beserk_Click);
            // 
            // sped
            // 
            this.sped.BackColor = System.Drawing.Color.Yellow;
            this.sped.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("sped.BackgroundImage")));
            this.sped.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.sped.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sped.ForeColor = System.Drawing.Color.Black;
            this.sped.Location = new System.Drawing.Point(278, 253);
            this.sped.Name = "sped";
            this.sped.Size = new System.Drawing.Size(105, 65);
            this.sped.TabIndex = 14;
            this.sped.Text = "Speed";
            this.sped.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.sped.UseVisualStyleBackColor = false;
            this.sped.Visible = false;
            this.sped.Click += new System.EventHandler(this.sped_Click);
            // 
            // fullHeal
            // 
            this.fullHeal.BackColor = System.Drawing.Color.Yellow;
            this.fullHeal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("fullHeal.BackgroundImage")));
            this.fullHeal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.fullHeal.Font = new System.Drawing.Font("Impact", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fullHeal.ForeColor = System.Drawing.Color.Black;
            this.fullHeal.Location = new System.Drawing.Point(411, 253);
            this.fullHeal.Name = "fullHeal";
            this.fullHeal.Size = new System.Drawing.Size(105, 65);
            this.fullHeal.TabIndex = 15;
            this.fullHeal.Text = "SweetBabyRays";
            this.fullHeal.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.fullHeal.UseVisualStyleBackColor = false;
            this.fullHeal.Visible = false;
            this.fullHeal.Click += new System.EventHandler(this.fullHeal_Click);
            // 
            // Combat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.fullHeal);
            this.Controls.Add(this.sped);
            this.Controls.Add(this.beserk);
            this.Controls.Add(this.smoke);
            this.Controls.Add(this.slots);
            this.Controls.Add(this.halfHeal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.goldL);
            this.Controls.Add(this.youH);
            this.Controls.Add(this.hell);
            this.Controls.Add(this.dio);
            this.Controls.Add(this.runBut);
            this.Controls.Add(this.passiveBut);
            this.Controls.Add(this.attackBut);
            this.Controls.Add(this.enemyPic);
            this.Controls.Add(this.heroPic);
            this.Name = "Combat";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.heroPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox heroPic;
        private System.Windows.Forms.PictureBox enemyPic;
        private System.Windows.Forms.Button attackBut;
        private System.Windows.Forms.Button passiveBut;
        private System.Windows.Forms.Button runBut;
        private System.Windows.Forms.Label dio;
        private System.Windows.Forms.Label hell;
        private System.Windows.Forms.Label youH;
        private System.Windows.Forms.Label goldL;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button halfHeal;
        private System.Windows.Forms.Button slots;
        private System.Windows.Forms.Button smoke;
        private System.Windows.Forms.Button beserk;
        private System.Windows.Forms.Button sped;
        private System.Windows.Forms.Button fullHeal;
    }
}