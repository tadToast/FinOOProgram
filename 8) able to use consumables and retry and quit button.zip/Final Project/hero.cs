﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    public class hero
    {
       public   Random rand = new Random();
     public    int health;
      static   string name = "Ted Cruz";
       public  int attackmax;
       public  int attackMin;
       public  int speed;
       public  int gold;
       public int lvl;
        public int exp;
        public int maxHealth;
        public int lvlNeeded;
        public int tmpMin = 0;
        public int tmpMax = 0;
            public int tmpSpeed = 0;



        //items consumables
       public int smoke = 0; //done
        public int slots = 0; //done
        public int sped = 0; //done
        public int halfheal = 0; //done
        public int fullHeal = 0; //done
        public int ber = 0; //done


        //perm buffs
        public int ster = 0;
        public int stem = 0;
        public int meth = 0;


        public void levelup()
        {
           
            int needed = lvl * 50;
            lvlNeeded = needed;
            while (exp >= needed)
            {
                if (needed <= exp)
                {
                    this.lvl++;
                   this.exp = exp - needed; ;
                    needed = lvl * 50;
                    lvlNeeded = needed;
                    this.health += 5;
                    this.maxHealth += 20;
                   this.attackmax += 10;
                   this.attackMin += 2;
                   this.speed = speed + (speed*2)/3;
                }
                else
                {
                    return;
                }
            }
            return;
        }
        public hero()
        {
           gold= rand.Next(0, 40);
            lvl = 1;
            health = 50 * lvl;
            maxHealth = 50 * lvl;
            attackmax = 10 * lvl;
            attackMin = 3* (lvl/2);
            speed = 50 * lvl;
           
        }
        public hero(hero youA)
        {
            this.lvl = youA.lvl;
            this.health = youA.health;
            this.attackmax = youA.attackmax;
            this.attackMin = youA.attackMin;
            this.speed = 100 * youA.speed;
            this.gold = youA.gold;
           this.maxHealth =youA.maxHealth;
          this.exp = youA.exp;
        }

        public int attack ()
        {
            int val;
            val = rand.Next(attackMin +tmpMin, attackmax+1 + tmpMax);
            return val;

        }
        public void healthgate()
        {
            if(maxHealth < health)
            {
                this.health = maxHealth;
                return;
            }
            else
            {
                return;
            }
        }
    }
}
