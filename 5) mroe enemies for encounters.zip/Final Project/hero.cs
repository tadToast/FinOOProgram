﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    public class hero
    {
       public   Random rand = new Random();
     public    int health;
      static   string name = "Ted Cruz";
       public  int attackmax;
       public  int attackMin;
       public  int speed;
       public  int gold;
       public int lvl;
        public int exp;

        public hero()
        {
            lvl = 1;
            health = 50 * lvl;
            attackmax = 10 * lvl;
            attackMin = 3* (lvl/2);
            speed = 100 * lvl;
            gold = 0;
        }
        public hero(hero youA)
        {
            lvl = youA.lvl;
            health = youA.health;
            attackmax = youA.attackmax;
            attackMin = youA.attackMin;
            speed = 100 * youA.speed;
            gold = youA.gold;
        }

        public int attack ()
        {
            int val;
            val = rand.Next(attackMin, attackmax+1);
            return val;

        }
    }
}
