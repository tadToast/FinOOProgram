﻿namespace Final_Project
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.heroPic = new System.Windows.Forms.PictureBox();
            this.enemyPic = new System.Windows.Forms.PictureBox();
            this.attackBut = new System.Windows.Forms.Button();
            this.passiveBut = new System.Windows.Forms.Button();
            this.runBut = new System.Windows.Forms.Button();
            this.dio = new System.Windows.Forms.Label();
            this.hell = new System.Windows.Forms.Label();
            this.youH = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.heroPic)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPic)).BeginInit();
            this.SuspendLayout();
            // 
            // heroPic
            // 
            this.heroPic.Image = ((System.Drawing.Image)(resources.GetObject("heroPic.Image")));
            this.heroPic.Location = new System.Drawing.Point(32, 107);
            this.heroPic.Name = "heroPic";
            this.heroPic.Size = new System.Drawing.Size(206, 206);
            this.heroPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.heroPic.TabIndex = 0;
            this.heroPic.TabStop = false;
            // 
            // enemyPic
            // 
            this.enemyPic.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.enemyPic.Location = new System.Drawing.Point(570, 24);
            this.enemyPic.Name = "enemyPic";
            this.enemyPic.Size = new System.Drawing.Size(192, 228);
            this.enemyPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPic.TabIndex = 1;
            this.enemyPic.TabStop = false;
            // 
            // attackBut
            // 
            this.attackBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.attackBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("attackBut.BackgroundImage")));
            this.attackBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.attackBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.attackBut.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.attackBut.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.attackBut.Location = new System.Drawing.Point(0, 330);
            this.attackBut.Name = "attackBut";
            this.attackBut.Size = new System.Drawing.Size(238, 120);
            this.attackBut.TabIndex = 2;
            this.attackBut.Text = "Attack";
            this.attackBut.UseVisualStyleBackColor = false;
            this.attackBut.Click += new System.EventHandler(this.attackBut_Click);
            // 
            // passiveBut
            // 
            this.passiveBut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.passiveBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("passiveBut.BackgroundImage")));
            this.passiveBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.passiveBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.passiveBut.ForeColor = System.Drawing.Color.Blue;
            this.passiveBut.Location = new System.Drawing.Point(279, 330);
            this.passiveBut.Name = "passiveBut";
            this.passiveBut.Size = new System.Drawing.Size(238, 120);
            this.passiveBut.TabIndex = 3;
            this.passiveBut.Text = "Love 😍";
            this.passiveBut.UseVisualStyleBackColor = false;
            // 
            // runBut
            // 
            this.runBut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("runBut.BackgroundImage")));
            this.runBut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.runBut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.runBut.Location = new System.Drawing.Point(550, 330);
            this.runBut.Name = "runBut";
            this.runBut.Size = new System.Drawing.Size(238, 120);
            this.runBut.TabIndex = 4;
            this.runBut.Text = "Run🏃‍♀️🏃‍♀️";
            this.runBut.UseVisualStyleBackColor = true;
            // 
            // dio
            // 
            this.dio.AutoSize = true;
            this.dio.BackColor = System.Drawing.Color.Yellow;
            this.dio.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.dio.ForeColor = System.Drawing.Color.Black;
            this.dio.Location = new System.Drawing.Point(377, 289);
            this.dio.Name = "dio";
            this.dio.Size = new System.Drawing.Size(0, 25);
            this.dio.TabIndex = 5;
            // 
            // hell
            // 
            this.hell.AutoSize = true;
            this.hell.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.hell.Location = new System.Drawing.Point(565, 227);
            this.hell.Name = "hell";
            this.hell.Size = new System.Drawing.Size(86, 25);
            this.hell.TabIndex = 6;
            this.hell.Text = "Health: ";
            // 
            // youH
            // 
            this.youH.AutoSize = true;
            this.youH.BackColor = System.Drawing.Color.Yellow;
            this.youH.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.25F);
            this.youH.Location = new System.Drawing.Point(27, 79);
            this.youH.Name = "youH";
            this.youH.Size = new System.Drawing.Size(86, 25);
            this.youH.TabIndex = 7;
            this.youH.Text = "Health: ";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.youH);
            this.Controls.Add(this.hell);
            this.Controls.Add(this.dio);
            this.Controls.Add(this.runBut);
            this.Controls.Add(this.passiveBut);
            this.Controls.Add(this.attackBut);
            this.Controls.Add(this.enemyPic);
            this.Controls.Add(this.heroPic);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.heroPic)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox heroPic;
        private System.Windows.Forms.PictureBox enemyPic;
        private System.Windows.Forms.Button attackBut;
        private System.Windows.Forms.Button passiveBut;
        private System.Windows.Forms.Button runBut;
        private System.Windows.Forms.Label dio;
        private System.Windows.Forms.Label hell;
        private System.Windows.Forms.Label youH;
    }
}