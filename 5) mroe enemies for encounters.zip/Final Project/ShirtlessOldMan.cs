﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Final_Project
{
    public  class ShirtlessOldMan: Enemy
    {
        public string imagepath = "shirtless old man.jpg";
           
      

       public  ShirtlessOldMan()
        {
            lvl = 1;
            maxattack = 0;
            minattack = 0;
            health = 20;
            name = "Greg";
            gold = rand.Next(20,51);
            exp = rand.Next(50, 100);
            startDio = " A lvl " + lvl + " shirtless old man has appeared";
        }
        public ShirtlessOldMan(int level)
        {
            if (level == 1)
                level = rand.Next(level, level + 2);
            else
                level = rand.Next(level - 1, level + 2);
            maxattack = 3*lvl;
            minattack = 1*lvl;
            health = 20*lvl;
            name = "Greg";
            gold = rand.Next(20*lvl, 51*lvl);
            exp = rand.Next(50*lvl, 100*lvl);
            startDio = " A lvl " + lvl + " shirtless old man has appeared";
        }
        public int violence()
        {
            int damage = rand.Next(minattack, maxattack);
            int genText = rand.Next(1, 4);
            if (genText == 1)
                attackText = "Where am I";
            else if (genText == 2)
                attackText = "Did you know that 9/11 was faked";
            else
                attackText = "I want to die :(";
          
            return damage;
        }

    }
}
