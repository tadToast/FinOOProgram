﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    public class Prince : Enemy
    {
        public string imagepath = "nigerian prince.jpg";


        public Prince()
        {
            lvl = 1;
            maxattack = 20;
            minattack = 5;
            health = 50;
            name = "Wealthy Prince";
            gold = rand.Next(-10, 200);
            exp = 0;
            startDio = " A lvl " + lvl + "Prince has appeared";
        }
        public Prince(int level)
        {
            if (level == 1)
                level = rand.Next(level, level + 2);
            else
                level = rand.Next(level - 1, level + 2);
            lvl = level;
            maxattack = 15 * lvl;
            minattack = 5 * lvl;
            health = 15 * lvl;
            name = "'Rich' Oil Prince";
            gold = rand.Next(-10 * lvl, 100 * lvl);
            exp = 0;
            startDio = " A lvl " + lvl + " Hansome Wealthy Prince  has appeared";
        }

        public int gamble()
        {
            int genText = rand.Next(1, 4);
            int act = rand.Next(1, 3);
            if (act == 1)
            {
                int goldSteal = rand.Next(minattack, maxattack);
                if (genText == 1)
                    attackText = "Please send 1 bitcoin to free me";
                else if (genText == 2)
                    attackText = "Please send moeny to unfreeze my account";
                else
                    attackText = "Please send gift card code!";

                gold += (goldSteal / 2);
                return goldSteal;
            }
            else
            {
                int goldGive = rand.Next(minattack, maxattack);
                goldGive = goldGive * -1;
                if (genText == 1)
                    attackText = "I wire you your money now";
                else if (genText == 2)
                    attackText = "Baby girl, I give money now";
                else
                    attackText = "You have helped me unfreeze my bank account";

                return goldGive;
            }
        }
    }
}
