﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
{
    public partial class Combat : Form
    {
        // Just using these for my button events
        int notClicked = 0;
        int damageFromBut;
        hero a;
        ShirtlessOldMan man;
        Wolf wolf;
        JamesCordan james;
        Prince prince;
        Form1 orginal;
        int com;
        int comOn = 0;
        /// 
        /// //////////
        ///
        public Combat()
        {
            InitializeComponent();
        }
        public Combat(int guy, hero character, Form1 og)
        {
            orginal = og;
            a = character;
            InitializeComponent();
            com = guy;
            updatePlayerStuff();
            dio.Visible = true;
            if(guy == 1) //shirtless old man encounter
            {
                if(character.lvl == 1)
                 man = new ShirtlessOldMan();
                else
                    man = new ShirtlessOldMan(character.lvl);
                enemyPic.Image = Image.FromFile(man.imagepath);
                           dio.Text = man.startDio;
                hell.Text = "Health:" +man.health;
            }
            else if(guy == 2) //wolf encounter
            {
                if (character.lvl == 1)
                    wolf = new Wolf();
                else
                    wolf = new Wolf(character.lvl);
                enemyPic.Image = Image.FromFile(wolf.imagepath);
                dio.Text = wolf.startDio;
                hell.Text = "Health:" + wolf.health;
            }
            else if ( guy == 3)//james cordan encounter
            {
                if (character.lvl == 1)
                    james = new JamesCordan();
                else
                    james = new JamesCordan(character.lvl);
                enemyPic.Image = Image.FromFile(james.imagepath);
                dio.Text = james.startDio;
                hell.Text = "Health:" + james.health;
            }
            else
            {
                if (character.lvl == 1)
                    prince = new Prince();
                else
                    prince = new Prince(character.lvl);
                enemyPic.Image = Image.FromFile(prince.imagepath);
                a = character;
                dio.Text = prince.startDio;
                hell.Text = "Health:" + prince.health;
                youH.Text = "Health:" + a.health;
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }


        private void passiveBut_Click(object sender, EventArgs e)
        {
            if(comOn ==0)
            {
                comOn = 1;
                viz();

            }
            else
            {
                comOn = 0;
                inviz();

            }
        }
        private void runBut_Click(object sender, EventArgs e)
        {
            if(com ==1)
            {
                if (man.speed > a.speed)
                {
                    dio.Text = "You are too slow";
                    ShirtlessOldManTurn();
                }
                else
                    run();
            }
            if(com ==2)
            {
                if (wolf.speed > a.speed)
                {
                    dio.Text = "Silly Billy, I am faster";
                    wolfTurn();
                }
                else
                    run();
            }
            if(com ==3)
            {
                if(james.speed > a.speed)
                {
                    dio.Text = "You can not escape";
                    jamesTurn();
                }
                else
                    run();
            }
            if(com ==4)
            {
                run();
            }
        }
        private void attackBut_Click(object sender, EventArgs e)
        {
            if (com==1) //shirtless old man combat
            {
                damageFromBut = a.attack();
                man.health -= damageFromBut;
                hell.Text = "Health:" + man.health;
                ShirtlessOldManTurn();

            }
            else if(com==2) //wolf combat
            {
                damageFromBut = a.attack();
                wolf.health -= damageFromBut;
                hell.Text = "Health:" + wolf.health;
                wolfTurn();
            }
            else if(com == 3) //james cordan combat
            {
                damageFromBut = a.attack();
                james.health -= damageFromBut;
                hell.Text = "Health:" + james.health;
                jamesTurn();

            }
            else if (com == 4) //prince combat
            {
                damageFromBut = a.attack();
                prince.health -= damageFromBut;
                hell.Text = "Health:" + prince.health;
                princeTurn();
            }
            
       }
        void endGame()
        {
            orginal.Show();
            orginal.endgame();
            this.Close();
        }
        void ShirtlessOldManTurn()
        {
            if (man.health <= 0)
            {
                int money = man.die();
                dio.Text = "You murdered an old man, here is " + money + " gold and " + man.exp + "exp";
                a.gold += money;
                a.exp += man.exp;
                a.levelup();
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                int delt = man.violence();
                dio.Text = man.attackText;
                a.health -= delt;
                a.healthgate();
                youH.Text = "Health:" + a.health;
                if (a.health <= 0)
                {
                    //gameover or something
                    endGame();

                }
            }
        }
        void wolfTurn()
        {
            if (wolf.health <= 0)
            {
                int money = wolf.die();
                dio.Text = "You deafeated a great beast, here is " + money + " gold and " + wolf.exp + "exp";
                a.gold += money;
                a.exp += wolf.exp;
                a.levelup();
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                int delt = wolf.Maul();
                dio.Text = wolf.attackText;
                a.health -= delt;
                a.healthgate();
                youH.Text = "Health:" + a.health;
                if (a.health <= 0)
                {
                    //gameover or something
                    endGame();

                }
            }
        }

        void jamesTurn()
        {
            if (james.health <= 0)
            {
                int money = james.die();
                dio.Text = "You deafeated british ellen, here is " + money + " gold and " + james.exp + "exp";
                a.gold += money;
                a.exp += james.exp;
                a.levelup();
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                int delt = james.ImFamous();
                dio.Text = james.attackText;
                a.health -= delt;
                a.healthgate();
                youH.Text = "Health:" + a.health;
                if (a.health <= 0)
                {
                    //gameover or something
                    endGame();

                }
            }

        }

        void princeTurn()
        {
            if (prince.health <= 0)
            {
                int money = prince.die();
                dio.Text = "You the Prince, here is " + money + " gold and " + prince.exp + "exp";
                a.gold += money;
                a.exp += prince.exp;
                a.levelup();
                orginal.you = a;
                orginal.update();
                orginal.Show();
                this.Close();
            }
            else
            {
                int delt = prince.gamble();
                if (delt == 4761)
                {
                    dio.Text = prince.attackText;
                    a.levelup();
                    orginal.you = a;
                    orginal.update();
                    orginal.Show();
                    this.Close();
                }
                else
                { 
                dio.Text = prince.attackText;
                a.gold -= delt;
                youH.Text = "Health:" + a.health;
                    goldL.Text = "Gold: " + a.gold;
                    if (a.health <= 0)
                {
                    //gameover or something
                    endGame();

                }
                }
            }
        }

    void viz()
        {
            if(a.halfheal > 0)  halfHeal.Visible = true;
            else halfHeal.Visible = false;

            if(a.fullHeal > 0) fullHeal.Visible = true;
            else fullHeal.Visible = false;

            if(a.smoke > 0) smoke.Visible = true;
            else smoke.Visible = false;

            if(a.ber > 0) beserk.Visible = true;
            else beserk.Visible = false;

            if(a.sped > 0) sped.Visible = true;
            else sped.Visible = false;

            if( a.slots > 0) slots.Visible = true;
            else slots.Visible = false;

        }
        void inviz()
        {
            halfHeal.Visible = false;
            fullHeal.Visible = false;
            smoke.Visible = false;
            beserk.Visible = false;
            sped.Visible = false;
            slots.Visible = false;
        }

        void run()
        {
            orginal.you = a;
            orginal.update();
            orginal.Show();
            this.Close();
        }

        private void halfHeal_Click(object sender, EventArgs e)
        {
            if(a.halfheal > 0)
            {
                a.halfheal--;

            }
        }
        void updatePlayerStuff()
        {
            youH.Text = "Health:" + a.health;
            goldL.Text = "Gold: " + a.gold;
        }
        private void slots_Click(object sender, EventArgs e)
        {

        }

        private void smoke_Click(object sender, EventArgs e)
        {

        }

        private void beserk_Click(object sender, EventArgs e)
        {

        }

        private void sped_Click(object sender, EventArgs e)
        {

        }

        private void fullHeal_Click(object sender, EventArgs e)
        {

        }
    }
}
