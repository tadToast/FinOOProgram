﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Xsl;

namespace Final_Project
{
    public partial class Form1 : Form
    {
        public hero you = new hero();
        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e) //These are just here to restrict what part of the map can be accessed, nothing to really see 
        {
            //considering being able to go back and fourth to ones that are not touched in a stage to add more encounters
            if ((String)this.left4.Tag == "touched" || (String)this.right4.Tag == "touched")
            {
                //do boss thing
                left1.AllowDrop = false;
                right1.AllowDrop = false;
                left2.AllowDrop = false; right2.AllowDrop = false;
                left3.AllowDrop = false; right3.AllowDrop = false;
                left4.AllowDrop = false; right4.AllowDrop = false;
            }
            else if ((String)this.left3.Tag == "touched" || (String)this.right3.Tag == "touched")
            {
                //do boss thing
                left1.AllowDrop = false;
                right1.AllowDrop = false;
                left2.AllowDrop = false; right2.AllowDrop = false;
                left3.AllowDrop = false; right3.AllowDrop = false;
                left4.AllowDrop = true; right4.AllowDrop = true;
            }
            else if ((String)this.left2.Tag == "touched" || (String)this.right2.Tag == "touched")
            {
                //do boss thing
                left1.AllowDrop = false;
                right1.AllowDrop = false;
                left2.AllowDrop = false; right2.AllowDrop = false;
                left3.AllowDrop = true; right3.AllowDrop = true;
                left4.AllowDrop = false; right4.AllowDrop = false;
            }
            else if ((String)this.left1.Tag == "touched" || (String)this.right1.Tag == "touched")
            {
                //do boss thing
                left1.AllowDrop = false;
                right1.AllowDrop = false;
                left2.AllowDrop = true; right2.AllowDrop = true;
                left3.AllowDrop = false; right3.AllowDrop = false;
                left4.AllowDrop = false; right4.AllowDrop = false;
            }
            else if ((String)this.Start.Tag == "began")
            {
                left1.AllowDrop = true;
                right1.AllowDrop = true;
                left2.AllowDrop = false; right2.AllowDrop = false;
                left3.AllowDrop = false; right3.AllowDrop = false;
                left4.AllowDrop = false; right4.AllowDrop = false;
            }
            else
            {
                left1.AllowDrop = true;
                right1.AllowDrop = true;
                left2.AllowDrop = true; right2.AllowDrop = true;
                left3.AllowDrop = true; right3.AllowDrop = true;
                left4.AllowDrop = true; right4.AllowDrop = true;
            }

        }
//the next two events are jsut for dragging and droping the pictures
        private void PictureBox_MouseDown(object sender, MouseEventArgs e)
        {
            ((PictureBox)sender).DoDragDrop(((PictureBox)sender).Image, DragDropEffects.Copy);
        }

        private void PictureBox_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Bitmap))
            {
                e.Effect = DragDropEffects.Copy;
            }
        }
    
        private void PictureBox_DragDrop(object sender, DragEventArgs e)
        {
            PictureBox pb = (PictureBox)sender;
            Image getPicture = (Bitmap)e.Data.GetData(DataFormats.Bitmap);
            //sets the picture of where you are draging to the one that you dragged over to it
            pb.Image = getPicture;
            pb.Tag = "touched";
            //labed the picture to trigger what the next access levels are 
            pb.AllowDrop = false;
            int encounter = you.rand.Next(1, 7); //determenis if encounter is a combat or a shop encounter
            if(encounter == 5 )
            {
                var m = new Shop(you, this);
                this.Hide();
                m.Show();
            }
            else{
                encounter = (encounter % 4) + 1;
                var m = new Combat(encounter, you, this);
                this.Hide();
                m.Show();
            }
          
            
            Form1_Load(sender, e);
        }
        
        public void endgame()
        {
            left1.Visible = false;
            right1.Visible = false;
            left2.Visible = false; right2.Visible = false;
            left3.Visible = false; right3.Visible = false;
            left4.Visible = false; right4.Visible = false;
            Start.Visible = false;
            goldL.Visible = false;
            lvlL.Visible = false;
            healthL.Visible = false;
            Map.Image = Image.FromFile("game over.jpg");
            gameOverT.Text = "You Lost";

        }
        public void update()
        {
            goldL.Text = "Gold: " + you.gold;
            lvlL.Text = "lvl: " + you.lvl;
            healthL.Text="Health: " + you.health + "/" + you.maxHealth;
        }

      }
}
