﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
{
    public partial class Form2 : Form
    {
        // Just using these for my button events
        int notClicked = 0;
        int damageFromBut;
        hero a;
        ShirtlessOldMan man;
        Form1 orginal;
        /// <summary>
        /// //////////
        /// </summary>
        public Form2()
        {
            InitializeComponent();
        }
        public Form2(int guy, hero character, Form1 og)
        {
            InitializeComponent();
            if(guy == 0) //so far, number is sent in and that decides what is made. The main character is also sent in but i do not know how to handle level ups so far
            {
                orginal = og;
                 man = new ShirtlessOldMan();
                enemyPic.Image = Image.FromFile(man.imagepath);
                a = character;
                dio.Text = man.startDio;
                hell.Text = "Health:" +man.health;
                youH.Text ="Health:" + character.health;
              //  combat(character, man);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

  
        int combat(hero a, ShirtlessOldMan b)//have to implement some sort of turn base
        {
            int turn = 0;
            int delt;
          
           while(a.health >= 0 || b.health >=0)
            {
                if(turn == 0)
                {
                    attackBut.Enabled = true;
                    passiveBut.Enabled = true;
                  /*  while(notClicked != 0)
                    {

                    }*/
                    notClicked = 1;
                    delt = damageFromBut;
                    b.health -= delt;
                    hell.Text = "Health:" + b.health;
                }
                else
                {
                    attackBut.Enabled = false;
                    passiveBut.Enabled = false;
                    delt = b.violence();
                    dio.Text = b.attackText;
                    a.health -= delt;
                    youH.Text = "Health:" + a.health;
                }
            }
            return 1;
        }

        private void attackBut_Click(object sender, EventArgs e)
        {
           
            damageFromBut = a.attack();
            man.health -= damageFromBut;
            hell.Text = "Health:" + man.health;
            if (man.health <= 0)
            {
               int money =man.die();
                dio.Text = "You murdered an old man, here is " + money + " gold and " + man.exp+ "exp";
                a.gold += money;
                a.exp += man.exp;
                orginal.you = a;
                orginal.Show();
                this.Close();
            }
            int delt = man.violence();
            dio.Text = man.attackText;
            a.health -= delt;
            youH.Text = "Health:" + a.health;
   
        }
    }
}
